<?php
header("content-type:text/html;charset=utf-8");
$msg;
$serverName = "localhost";
$connInfo = array("Database"=>"HRM", "UID"=>"sa", "PWD"=>"123456");
$conn = sqlsrv_connect($serverName, $connInfo);
if($conn){
}else{
 echo "connect error<br />";
 die( print_r(sqlsrv_errors(), true));
}
$str1="";$str2="";
$sql = "select * from  FirstIst;"; 
$data = sqlsrv_query($conn,$sql);
if($data == true){
   while($row = sqlsrv_fetch_array( $data, SQLSRV_FETCH_ASSOC) ) {
	   $row['FirstIstName']= (iconv('GBK','UTF-8',$row['FirstIstName']));
		  $str1=$str1.";".$row['FirstIstName'];
		 $str2=$str2.";".$row['FId'];
    } 
	echo $str1.":".$str2;
}else{
    die("execute error");
    }
?>