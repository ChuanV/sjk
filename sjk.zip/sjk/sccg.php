<?php
header("content-type:text/html;charset=utf-8");
error_reporting(E_ERROR); 
ini_set("display_errors","Off");
$bh=$_POST['bh'];
$serverName = "localhost";
$connInfo = array("Database"=>"HRM", "UID"=>"sa", "PWD"=>"123456");
$conn = sqlsrv_connect($serverName, $connInfo);
if($conn){
}else{
 echo "connect error<br />";
 die( print_r(sqlsrv_errors(), true));
}
$msg;
$sql="delete from personal where personal.pNO='$bh'";
  //echo $sql; 
$data = sqlsrv_query($conn,$sql);
if($data == true){
	
	$msg=1;
    echo $msg;
}else{
	$msg=0;
	echo $msg;
    die("execute error");
    }
?>