<?php
header("content-type:text/html;charset=utf-8");
error_reporting(E_ERROR); 
ini_set("display_errors","Off");
$ThirdIst=$_POST['ThirdIst'];//$ThirdIst='01';
$zwmc=$_POST['zwmc'];//$zwmc='01';
//echo $ThirdIs.";".$zwmc;
$serverName = "localhost";
$connInfo = array("Database"=>"HRM", "UID"=>"sa", "PWD"=>"123456");
$conn = sqlsrv_connect($serverName, $connInfo);
if($conn){
}else{
 echo "connect error<br />";
 die( print_r(sqlsrv_errors(), true));
}
$msg;
$sql="select pNO,pSname,pSex,FirstIstName,SecondIstName,ThirdIstName,Postname from personal,post,FirstIst,SecondIst,ThirdIst where ThirdIst.SId=SecondIst.SId and
SecondIst.FId=FirstIst.FId and ThirdIst.TId=personal.TId and ThirdIst.TId='$ThirdIst' and post.PostId=personal.PostId and post.PostId='$zwmc'";
  //echo $sql; 
$data = sqlsrv_query($conn,$sql);
if($data == true){
	 while($row = sqlsrv_fetch_array( $data, SQLSRV_FETCH_ASSOC) ) {
		$row['pSname']= (iconv('GBK','UTF-8',$row['pSname']));
		$row['pSex']= (iconv('GBK','UTF-8',$row['pSex']));
		$row['FirstIstName']= (iconv('GBK','UTF-8',$row['FirstIstName']));
		$row['SecondIstName']= (iconv('GBK','UTF-8',$row['SecondIstName']));
		$row['ThirdIstName']= (iconv('GBK','UTF-8',$row['ThirdIstName']));
		$row['Postname']= (iconv('GBK','UTF-8',$row['Postname']));
	    $msg=$msg.";".$row['pNO'].",".$row['pSname'].",".$row['pSex'].",".$row['FirstIstName'].",".$row['SecondIstName'].",".$row['ThirdIstName'].",".$row['Postname'];
	 }   
	//$msg=1;
	echo $msg;
}else{
	$msg=0;
	echo $msg;
    die("execute error");
    }
?>