<?php
header("content-type:text/html;charset=utf-8");
error_reporting(E_ERROR); 
ini_set("display_errors","Off");
$bh=$_POST['bh'];
$serverName = "localhost";
$connInfo = array("Database"=>"HRM", "UID"=>"sa", "PWD"=>"123456");
$conn = sqlsrv_connect($serverName, $connInfo);
if($conn){
}else{
 echo "connect error<br />";
 die( print_r(sqlsrv_errors(), true));
}
$msg;
$sql="select personal.*,FirstIst.FirstIstName,SecondIst.SecondIstName,ThirdIst.ThirdIstName,PostClassify.ClassifyName,post.Postname from personal,SecondIst,ThirdIst,FirstIst,PostClassify,post where post.PostId=personal.PostId 
 and post.PostClassifyId=PostClassify.PostClassifyId and ThirdIst.TId=personal.TId and SecondIst.SId=ThirdIst.SId
and FirstIst.FId=SecondIst.FId and personal.pNO='$bh'";
  //echo $sql; 
$data = sqlsrv_query($conn,$sql);
if($data == true){
	$res=array('pSname','pSex','pAddress','pNationality','pFaith','pPolStatus','FirstIstName','SecondIstName','ThirdIstName','ClassifyName','Postname');
	$arrlength=count($res);
	 while($row = sqlsrv_fetch_array( $data, SQLSRV_FETCH_ASSOC) ) {
		 for($x=0;$x<$arrlength;$x++){
			 	$row[$res[$x]]= (iconv('GBK','UTF-8',$row[$res[$x]]));
		 }
	    $msg=$msg.";".$row['pNO'].",".$row['pSname'].",".$row['pSex'].",".$row['pEmail'].",".$row['pPhone'].",".$row['pQQ'].",".$row['pCellPhone'].",".$row['pAddress'].","
		.$row['pPostcode'].",".$row['pNationality'].",".$row['pFaith'].",".$row['pPolStatus'].",".$row['pIdcard'].",".$row['FirstIstName'].",".$row['SecondIstName'].",".$row['ThirdIstName'].",".$row['ClassifyName'].",".$row['Postname'];
	 }   
	//$msg=1;
	echo $msg;
}else{
	$msg=0;
	echo $msg;
    die("execute error");
    }
?>