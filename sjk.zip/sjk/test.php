<?php
header("content-type:text/html;charset=utf-8");
error_reporting(E_ERROR); 
ini_set("display_errors","Off");
 $res=array('pemail','ptel','pqq','psj','pyb','psfz','djdate','pname','psex','pdz','pmz','pzjxy','pzjmm');
 for($i=0;$i<count($res);$i++){
 	$res[$i]=$_POST[$res[$i]];
 	//对汉字进行编码
 	if($i>6){
 		$res[$i]=(iconv('UTF-8','GBK',$res[$i]));
 	}
 }
 $oobh=$_POST['oobh'];
 $zwmc=$_POST['zwmc'];
$FirstIst=$_POST['FirstIst'];
$SecondIst=$_POST['SecondIst'];
$ThirdIst=$_POST['ThirdIst'];
$year=$_POST['year'];
$pbh=$year.$FirstIst.$SecondIst.$ThirdIst.$oobh;
$serverName = "localhost";
$connInfo = array("Database"=>"HRM", "UID"=>"sa", "PWD"=>"123456");
$conn = sqlsrv_connect($serverName, $connInfo);
if($conn){
}else{
 echo "connect error<br />";
 die( print_r(sqlsrv_errors(), true));
}
$msg;
$sql="insert into personal values('$pbh', '$res[7]','$res[8]','$res[0]','$res[1]','$res[2]',
'$res[3]','$res[9]','$res[4]','$res[10]','$res[11]','$res[12]','$res[5]','$zwmc','$ThirdIst','admin','$res[6]','N')";
$data = sqlsrv_query($conn,$sql);
if($data == true){
	$msg=1;
	echo $msg;
}else{
	$msg=0;
	echo $msg;
    die("execute error");
    }
?>