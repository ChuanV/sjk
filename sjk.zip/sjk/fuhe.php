<?php
header("content-type:text/html;charset=utf-8");
error_reporting(E_ERROR); 
ini_set("display_errors","Off");
$serverName = "localhost";
$connInfo = array("Database"=>"HRM", "UID"=>"sa", "PWD"=>"123456");
$conn = sqlsrv_connect($serverName, $connInfo);
if($conn){
}else{
 echo "connect error<br />";
 die( print_r(sqlsrv_errors(), true));
}
$msg;
$sql="select distinct(pNO),pSname,pSex,FirstIstName,SecondIstName,ThirdIstName,Postname from personal,post,FirstIst,SecondIst,ThirdIst where ThirdIst.SId=SecondIst.SId and
SecondIst.FId=FirstIst.FId and post.PostId=personal.PostId and ThirdIst.TId=personal.TId and personal.pPass='N'";
  //echo $sql; 
$data = sqlsrv_query($conn,$sql);
if($data == true){
	$res=array('pSname','pSex','FirstIstName','SecondIstName','ThirdIstName','Postname');
	 while($row = sqlsrv_fetch_array( $data, SQLSRV_FETCH_ASSOC) ) {
		 for($i=0;$i<count($res);$i++){
			$row[$res[$i]]= (iconv('GBK','UTF-8',$row[$res[$i]]));
		 }
	    $msg=$msg.";".$row['pNO'].",".$row['pSname'].",".$row['pSex'].",".$row['FirstIstName'].",".$row['SecondIstName'].",".$row['ThirdIstName'].",".$row['Postname'];
	 }   
	//$msg=1;
	echo $msg;
}else{
	$msg=0;
	echo $msg;
    die("execute error");
    }
?>