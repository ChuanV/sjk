$(function(){
	/*************************建档时间设置*******************/
	var myDate = new Date();//获取系统当前时间
	var djdate=myDate.getFullYear()+"-"+myDate.getMonth()+1+"-"
	+myDate.getDate()+" "+myDate.getHours()+":"+myDate.getMinutes()+
	":"+myDate.getSeconds();
	$("#pjdsj").val(djdate);
	/*************************机构联动加载*******************/
	var FirstIst,SecondIst,ThirdIst,zwfl,zwmc,zc,sex,pgj,pmz,pzjxy,pzjmm;
	var zwmcT,zcT,ThirdIstT;
	ajax("liandong1.php",0,$("#FirstIst"));
	$("#FirstIst").change(function(){
			FirstIst=$(this).val();
			if(!$(this).val()){$("#SecondIst").find("option").remove();return;} 
			ajax("liandong2.php",$(this).val(),$("#SecondIst"));
	})
	$("#SecondIst").change(function(){
			SecondIst=$(this).val();
			if(!$(this).val()){$("#ThirdIst").find("option").remove();return;}
			ajax("liandong3.php",$(this).val(),$("#ThirdIst"));
	})
	/*************************职位联动加载*******************/
	ajax("PostClassify.php",0,$("#zwfl"));
	$("#zwfl").change(function(){
			zwfl=$(this).val();
			if(!$(this).val()){$("#zwmc").find("option").remove();return;}
			ajax("PostClassify1.php",$(this).val(),$("#zwmc"));
	})
	/*************************获取select的值*******************/
	$("#zwmc").change(function(){zwmc=$(this).val();zwmcT=$(this).find("option:selected").text();})
	$("#zc").change(function(){zc=$(this).val();})
	$("#ThirdIst").change(function(){ThirdIst=$(this).val();})
	/*************************请求方法*******************/
	function ajax(url,data,obj){
				$.ajax({
					url:url,
					data:{sid:data},
					success:function(result){
						var str="<option value=''></option>";
						var result = result.split(":");
						var res0=result[0].split(";");
						var res1=result[1].split(";");
						for(var i=1;i<=res0.length-1;i++){
							str+="<option value='"+res1[i]+"'>"+res0[i]+"</option>";
						}
						obj.find("option").remove();
						obj.append(str);
					}
				})
	}		
	/*************************清除按钮功能*******************/
	$("#qc").click(function(){
		$("input[id!='pjdsj']").val("");
		$("select").val("");
	})
	$("#tc").click(function(){
		window.location.href="zhuye.html";
	})
	/*************************提交按钮功能*******************/
	$("#tj").click(function(){
		if(!(FirstIst&&SecondIst&&ThirdIst)){alert("请选择机构");return;}  
		if(!($("#oobh").val()&&$("#oobh").val().length==2)){alert("请填写编号,两位数字");return;}
		if(!(zwfl&&zwmc)){alert("请选择职位");return;} 
		if(!$("#sex").val()){alert("选择性别");return;}
		if(!$("#pmz").val()){alert("选择民族");return;}
		if(!$("#pzjxy").val()){alert("选择宗教信仰");return;}
		if(!$("#pzjmm").val()){alert("选择政治面貌");return;}
		if(!($("#pname").val()&&$("#pemail").val()&&$("#ptel").val()&&$("#pqq").val()
		&&$("#psj").val()&&$("#pdz").val()&&$("#pyb").val()&&$("#psfz").val())){
			alert("请填入相关信息");return;
		}
		console.log($("#oobh").val().length);
		$.ajax({
			url:"test.php",
			data:{pname:$("#pname").val(),psex:$("#sex").val(),pemail:$("#pemail").val(),ptel:$("#ptel").val(),
			pqq:$("#pqq").val(),psj:$("#psj").val(),pdz:$("#pdz").val(),pyb:$("#pyb").val(),pcsd:$("#pcsd").val(),
			psfz:$("#psfz").val(),FirstIst:FirstIst,SecondIst:SecondIst,ThirdIst:ThirdIst,year:myDate.getFullYear(),
			pmz:$("#pmz").val(),pzjxy:$("#pzjxy").val(),pzjmm:$("#pzjmm").val(),djdate:djdate,zwmc:zwmc,oobh:$("#oobh").val()},
			type:"POST",
			success:function(result){
				if(result==1){
					alert("登记成功");
					window.location.href='fuhe.html';
				}else{
					alert("登记失败");
					}
			}
		})
	})
	/*************************查询按钮功能*******************/
	$("#cx").click(function(){
		if(!(ThirdIst&&zwmc)){
			alert("请选择完整信息");
			return;
		}
		$.ajax({
			url:"chaxun.php",
			type:"POST",
			data:{ThirdIst:ThirdIst,zwmc:zwmc},
			success:function(result){
				var result = result.split(";");
				var td;
				var tr="<tr><th>档案编号</th><th>姓名</th><th>性别</th><th>一级机构</th><th>二级机构</th><th>三级机构</th><th>职位名称</th><th>查询</th></tr>";
				for(var i=1;i<result.length;i++){
					result[i]=result[i].split(",");
					for(var j=0;j<result[i].length;j++){
						td+="<td>"+result[i][j]+"</td>";
					}
					td="<tr>"+td+"<td><button type='button' class='ckxqbtn'>查看详情</button></td></tr>";
				}
					tr+=td;
				$("#cxjg").find('tr').remove();
				$("#cxjg").append(tr);
			}
		})
	})
    /*************************复核页面加载*******************/
	$.ajax({
		url:"fuhe.php",
		success:function(result){
			var result = result.split(";");
			var td="";
			var tr="<tr><th>档案编号</th><th>姓名</th><th>性别</th><th>一级机构</th><th>二级机构</th><th>三级机构</th><th>职位名称</th><th>复核</th></tr>";
			for(var i=1;i<result.length;i++){
				result[i]=result[i].split(",");
				for(var j=0;j<result[i].length;j++){
					td+="<td>"+result[i][j]+"</td>";
				}
 				td="<tr>"+td+"<td><button type='button' class='fhbtn'>复核</button></td></tr>";
			}
			tr+=td;
			$("#fuhe").append(tr);
			 }
	})
	 /*************************复核按钮事件*******************/
	//为动态的元素绑定事件用on。这是一个坑啊，浪我时间。直接绑定不行
	$("#fuhe").on("click",".fhbtn",function(){
		var bh=$(this).parents("tr").find("td:first").text();
		$.ajax({
			url:"fuhe1.php",
			type:"POST",
			data:{bh:bh},
			success:function(result){
				var result = result.split(";");
				var result=result[1].split(",");
				console.log(result);
				$("body").load("fuhe1.html",function(){
				var array=new Array("#pname","#sex","#pemail","#ptel","#pqq",
				"#psj","#pdz","#pyb","#pmz","#pzjxy","#pzjmm","#psfz","#FirstIst","#SecondIst","#ThirdIst","#zwfl","#zwmc");
					for(var i=1;i<=17;i++){
						$(array[i-1]).val(result[i]);
					}
					$("#bh").text("编号:"+result[0]);
				})
				},
		})
	})
	/*************************通过复核按钮事件*******************/
	//console.log($("#pmz").val());
	$("#tgfh").click(function(){
		//console.log($("#bh").text().substring(3));
		if(!$("#sex").val()){alert("选择性别");return;}
		if(!$("#pmz").val()){alert("选择民族");return;}
		if(!$("#pzjxy").val()){alert("选择宗教信仰");return;}
		if(!$("#pzjmm").val()){alert("选择政治面貌");return;}
		if(!($("#pname").val()&&$("#pemail").val()&&$("#ptel").val()&&$("#pqq").val()
			&&$("#psj").val()&&$("#pdz").val()&&$("#pyb").val()&&$("#psfz").val())){
			alert("请填入相关信息");return;
		}
		$.ajax({
			url:"fuhecg.php",
			type:"POST",
			data:{pname:$("#pname").val(),psex:$("#sex").val(),pemail:$("#pemail").val(),ptel:$("#ptel").val(),
			pqq:$("#pqq").val(),psj:$("#psj").val(),pdz:$("#pdz").val(),pyb:$("#pyb").val(),
			psfz:$("#psfz").val(),pmz:$("#pmz").val(),pzjxy:$("#pzjxy").val(),pzjmm:$("#pzjmm").val(),djdate:djdate,bh:$("#bh").text().substring(3)},
			success:function(result){
				if(result==1){
					alert("通过复核");
					window.location.href='fuhe.html';
				}else{
					alert("复核失败");
					}
			},
			
		})
	})
	/*************************查看详情按钮事件*******************/
	$("#cxjg").on("click",".ckxqbtn",function(){
		var bh=$(this).parents("tr").find("td:first").text();
		$.ajax({
			url:"fuhe1.php",
			type:"POST",
			data:{bh:bh},
			success:function(result){
				var result = result.split(";");
				var result=result[1].split(",");
				console.log(result);
				$("body").load("fuhe1.html",function(){
				var array=new Array("#pname","#sex","#pemail","#ptel","#pqq",
				"#psj","#pdz","#pyb","#pmz","#pzjxy","#pzjmm","#psfz","#FirstIst","#SecondIst","#ThirdIst","#zwfl","#zwmc");
					for(var i=1;i<=17;i++){
						$(array[i-1]).val(result[i]);
					}
					$("#bh").text("编号:"+result[0]);
					$("#tgfh").text("变更");
					$("#tgfh").attr("id","bg");
				})
			},
		})
	})
	/*************************变更按钮事件*******************/
	$("#bg").click(function(){
		if(!$("#sex").val()){alert("选择性别");return;}
		if(!$("#pmz").val()){alert("选择民族");return;}
		if(!$("#pzjxy").val()){alert("选择宗教信仰");return;}
		if(!$("#pzjmm").val()){alert("选择政治面貌");return;}
		if(!($("#pname").val()&&$("#pemail").val()&&$("#ptel").val()&&$("#pqq").val()
			&&$("#psj").val()&&$("#pdz").val()&&$("#pyb").val()&&$("#psfz").val())){
			alert("请填入相关信息");return;
		}
		$.ajax({
			url:"bg.php",
			type:"POST",
			data:{pname:$("#pname").val(),psex:$("#sex").val(),pemail:$("#pemail").val(),ptel:$("#ptel").val(),
			pqq:$("#pqq").val(),psj:$("#psj").val(),pdz:$("#pdz").val(),pyb:$("#pyb").val(),
			psfz:$("#psfz").val(),pmz:$("#pmz").val(),pzjxy:$("#pzjxy").val(),pzjmm:$("#pzjmm").val(),djdate:djdate,bh:$("#bh").text().substring(3)},
			success:function(result){
				if(result==1){
					alert("变更成功");
					window.location.href='chaxun.html';
				}else{
					alert("变更失败");
					}
			},
			
		})
	})
	 /*************************删除页面加载*******************/
	 $.ajax({
	 	url:"sc.php",
	 	success:function(result){
	 		var result = result.split(";");
	 		var td="";
	 		var tr="<tr><th>档案编号</th><th>姓名</th><th>性别</th><th>一级机构</th><th>二级机构</th><th>三级机构</th><th>职位名称</th><th>操作</th></tr>";
	 		for(var i=1;i<result.length;i++){
	 			result[i]=result[i].split(",");
	 			for(var j=0;j<result[i].length;j++){
	 				td+="<td>"+result[i][j]+"</td>";
	 			}
	 			td="<tr>"+td+"<td><button type='button' class='sccg'>删除</button></td></tr>";
	 		}
	 		tr+=td;
	 		$("#sc").append(tr);
	 		 }
	 })
	  /*************************删除按钮事件*******************/
	  $("#sc").on("click",".sccg",function(){
		 var bh=$(this).parents("tr").find("td:first").text();
		 var qr=confirm("确定要删除？数据不可以还原了");
		 if(qr!=true){
			 return;
		 }
		// alert(bh);
		 $.ajax({
		 	url:"sccg.php",
		 	type:"POST",
		 	data:{bh:bh},
		 	success:function(result){
				if(result==1){
					alert("删除成功");
					window.location.reload();
				}else{
						alert("删除失败");
				}
				
				}
		  })
	})
})