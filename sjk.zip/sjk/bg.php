<?php
header("content-type:text/html;charset=utf-8");
error_reporting(E_ERROR); 
ini_set("display_errors","Off");
 $res=array('bh','pemail','ptel','pqq','psj','pyb','psfz','djdate','pname','psex','pdz','pmz','pzjxy','pzjmm');
for($i=0;$i<count($res);$i++){
	$res[$i]=$_POST[$res[$i]];
	//对汉字进行编码
	if($i>7){
		$res[$i]=(iconv('UTF-8','GBK',$res[$i]));
	}
}
$serverName = "localhost";
$connInfo = array("Database"=>"HRM", "UID"=>"sa", "PWD"=>"123456");
$conn = sqlsrv_connect($serverName, $connInfo);
if($conn){
}else{
 echo "connect error<br />";
 die( print_r(sqlsrv_errors(), true));
}
$msg;
 $sql = "update personal SET  personal.pSname='$res[8]',personal.pSex='$res[9]',personal.pEmail='$res[1]',
 personal.pPhone='$res[2]',personal.pQQ='$res[3]',personal.pCellPhone='$res[4]',personal.pAddress='$res[10]',
 personal.pPostcode='$res[4]',personal.pNationality='$res[11]',personal.pFaith='$res[12]',
 personal.pPolStatus='$res[13]',personal.pIdcard='$res[6]'  where personal.pNO='$res[0]'"; 
 // echo $sql; 
$data = sqlsrv_query($conn,$sql);
if($data == true){
	$msg=1;
	echo $msg;
}else{
	$msg=0;
	echo $msg;
    die("execute error");
    }
?>