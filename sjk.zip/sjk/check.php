<?php
header("content-type:text/html;charset=utf-8");
$user=$_POST["user"];
$pwd=$_POST['pwd'];
$msg;
//echo $user."hello";
$serverName = "localhost";
$connInfo = array("Database"=>"HRM", "UID"=>"sa", "PWD"=>"123456");
$conn = sqlsrv_connect($serverName, $connInfo);
if($conn){
 //echo "连接成功.<br />";
}else{
 echo "连接失败.<br />";
 die( print_r(sqlsrv_errors(), true));
}
$sql = "select * from  manager where usename='".$user."' and password='".$pwd."';";//sql语句
$data = sqlsrv_query($conn,$sql);  //$conn资源句柄
if($data == true){
   if($row = sqlsrv_fetch_array( $data, SQLSRV_FETCH_ASSOC) ) {
		 $msg=1;
		 echo $msg;
    }else{
		$msg=0;
		 echo $msg;
	}   
}else{
    die("执行失败");
    }
?>