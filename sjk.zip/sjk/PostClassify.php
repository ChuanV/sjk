<?php
header("content-type:text/html;charset=GBK");
error_reporting(E_ERROR); 
ini_set("display_errors","Off");
$msg;
//echo $user."hello";
//$sid=$_GET['sid'];
$serverName = "localhost";
$connInfo = array("Database"=>"HRM", "UID"=>"sa", "PWD"=>"123456");
$conn = sqlsrv_connect($serverName, $connInfo);
if($conn){
}else{
 echo "connect error<br />";
 die( print_r(sqlsrv_errors(), true));
}
$data=array();
$str1="";$str2="";
$sql = "select * from  PostClassify ;"; 
$stmt = sqlsrv_query($conn,$sql);
if($stmt == true){
   while($row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
		 //array_push($data,iconv('GBK','UTF-8',$row['SecondIstName']));
		 $str1=$str1.";".$row['ClassifyName'];
		 $str2=$str2.";".$row['PostClassifyId'];
    } 
	//$json=json_encode($data,JSON_UNESCAPED_UNICODE);
	//$str = implode(";", $data);
	echo $str1.":".$str2;
	//echo var_dump($json);
	//die();
}else{
    die("execute error");
    }
?>